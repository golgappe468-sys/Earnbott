const User = require('../models/User');
const config = require('../config');

const isAdmin = async (ctx, next) => {
  const userId = ctx.from.id;
  if (!config.ADMIN_IDS.includes(userId)) {
    return ctx.reply('⛔ This command is for admins only.');
  }
  return next();
};

const isNotBanned = async (ctx, next) => {
  try {
    const user = await User.findOne({ telegramId: ctx.from.id });
    if (user && user.isBanned) {
      return ctx.reply('🚫 Your account has been banned.');
    }
    return next();
  } catch (error) {
    console.error('Ban check error:', error);
    return next();
  }
};

const checkForceJoin = async (ctx, next) => {
  try {
    const userId = ctx.from.id;
    const settings = await require('../models/Settings').findOne({ key: 'settings' });
    const channelId = settings ? settings.value.forceJoinChannelId : config.FORCE_JOIN_CHANNEL_ID;
    
    try {
      const chatMember = await ctx.telegram.getChatMember(channelId, userId);
      if (['member', 'administrator', 'creator'].includes(chatMember.status)) {
        return next();
      }
    } catch (error) {
      console.log('Force join check failed:', error.message);
    }
    
    const channelUsername = settings ? settings.value.forceJoinChannel : config.FORCE_JOIN_CHANNEL;
    return ctx.reply(
      '🔒 *You must join our channel to use this bot!*\n\n' +
      'Please join the channel and click Verify button.',
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '📢 Join Channel', url: `https://t.me/${channelUsername.replace('@', '')}` }],
            [{ text: '✅ Verify', callback_data: 'verify_join' }]
          ]
        }
      }
    );
  } catch (error) {
    console.error('Force join middleware error:', error);
    return next();
  }
};

module.exports = { isAdmin, isNotBanned, checkForceJoin };