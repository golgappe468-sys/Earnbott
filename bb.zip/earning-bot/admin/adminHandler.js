const User = require('../models/User');
const Task = require('../models/Task');
const Withdrawal = require('../models/Withdrawal');
const Settings = require('../models/Settings');
const config = require('../config');
const { formatCurrency, formatDate } = require('../utils/helpers');
const { adminKeyboard, broadcastTypeKeyboard, withdrawalActionKeyboard, settingsKeyboard } = require('../keyboards/adminKeyboard');
const { mainMenuKeyboard } = require('../keyboards/mainMenu');

// Store admin sessions
const adminSessions = new Map();

const adminHandler = async (ctx) => {
  try {
    const userId = ctx.from.id;
    
    if (!config.ADMIN_IDS.includes(userId)) {
      return ctx.reply('⛔ Access denied.');
    }
    
    await ctx.reply(
      '⚙ *Admin Panel*\n\nSelect an action:',
      {
        parse_mode: 'Markdown',
        ...adminKeyboard()
      }
    );
    
  } catch (error) {
    console.error('Admin handler error:', error);
    await ctx.reply('❌ Error loading admin panel.');
  }
};

const adminCallbackHandler = async (ctx) => {
  try {
    const userId = ctx.from.id;
    if (!config.ADMIN_IDS.includes(userId)) {
      return ctx.answerCbQuery('⛔ Admin only!', { show_alert: true });
    }
    
    const action = ctx.callbackQuery.data;
    
    switch (action) {
      case 'admin_add_task':
        await startAddTask(ctx);
        break;
      case 'admin_edit_task':
        await showTasksForEdit(ctx);
        break;
      case 'admin_delete_task':
        await showTasksForDelete(ctx);
        break;
      case 'admin_withdrawals':
        await showWithdrawals(ctx);
        break;
      case 'admin_broadcast':
        await showBroadcastOptions(ctx);
        break;
      case 'admin_stats':
        await showStatistics(ctx);
        break;
      case 'admin_settings':
        await showSettings(ctx);
        break;
      case 'admin_close':
        await ctx.deleteMessage();
        break;
      case 'admin_back':
        await adminHandler(ctx);
        break;
      default:
        await ctx.answerCbQuery('Unknown action', { show_alert: true });
    }
    
  } catch (error) {
    console.error('Admin callback error:', error);
    await ctx.answerCbQuery('❌ Error processing action.', { show_alert: true });
  }
};

// Add Task
const startAddTask = async (ctx) => {
  adminSessions.set(ctx.from.id, { action: 'add_task', step: 'title' });
  await ctx.reply(
    '➕ *Add New Task*\n\nEnter task title:',
    {
      parse_mode: 'Markdown',
      reply_markup: {
        keyboard: [[{ text: '❌ Cancel' }]],
        resize_keyboard: true
      }
    }
  );
};

// Edit Task
const showTasksForEdit = async (ctx) => {
  const tasks = await Task.find({ status: 'active' }).limit(10);
  
  if (tasks.length === 0) {
    return ctx.reply('No active tasks to edit.');
  }
  
  const buttons = tasks.map(task => [
    { text: task.title, callback_data: `edit_task_${task._id}` }
  ]);
  buttons.push([{ text: '🔙 Back', callback_data: 'admin_back' }]);
  
  await ctx.reply('Select task to edit:', {
    reply_markup: { inline_keyboard: buttons }
  });
};

// Delete Task
const showTasksForDelete = async (ctx) => {
  const tasks = await Task.find({});
  
  if (tasks.length === 0) {
    return ctx.reply('No tasks to delete.');
  }
  
  const buttons = tasks.map(task => [
    { text: `${task.status === 'active' ? '🟢' : '🔴'} ${task.title}`, callback_data: `delete_task_${task._id}` }
  ]);
  buttons.push([{ text: '🔙 Back', callback_data: 'admin_back' }]);
  
  await ctx.reply('Select task to delete:', {
    reply_markup: { inline_keyboard: buttons }
  });
};

// Withdrawals
const showWithdrawals = async (ctx) => {
  const pendingWithdrawals = await Withdrawal.find({ status: 'pending' }).sort({ createdAt: -1 }).limit(10);
  
  if (pendingWithdrawals.length === 0) {
    return ctx.reply('✅ No pending withdrawals.');
  }
  
  for (const withdrawal of pendingWithdrawals) {
    const user = await User.findOne({ telegramId: withdrawal.userId });
    await ctx.reply(
      `💸 *Withdrawal Request*\n\n` +
      `👤 User: ${withdrawal.username}\n` +
      `🆔 ID: ${withdrawal.userId}\n` +
      `💰 Amount: ${formatCurrency(withdrawal.amount)}\n` +
      `📱 UPI: ${withdrawal.upiId}\n` +
      `📅 Date: ${formatDate(withdrawal.createdAt)}\n` +
      `💵 User Balance: ${user ? formatCurrency(user.balance) : 'Unknown'}`,
      {
        parse_mode: 'Markdown',
        ...withdrawalActionKeyboard(withdrawal._id)
      }
    );
  }
};

// Broadcast
const showBroadcastOptions = async (ctx) => {
  adminSessions.set(ctx.from.id, { action: 'broadcast', step: 'type' });
  await ctx.reply('Select broadcast type:', broadcastTypeKeyboard());
};

// Statistics
const showStatistics = async (ctx) => {
  try {
    const totalUsers = await User.countDocuments();
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    
    const todayUsers = await User.countDocuments({ createdAt: { $gte: todayStart } });
    const pendingWithdrawals = await Withdrawal.countDocuments({ status: 'pending' });
    const completedWithdrawals = await Withdrawal.countDocuments({ status: 'approved' });
    
    const totalPaid = await Withdrawal.aggregate([
      { $match: { status: 'approved' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);
    
    const activeTasks = await Task.countDocuments({ status: 'active' });
    const expiredTasks = await Task.countDocuments({ status: { $in: ['expired', 'completed'] } });
    
    const statsMessage = `
📊 *Bot Statistics*

👥 *Users*
• Total: ${totalUsers}
• Today: ${todayUsers}

💸 *Withdrawals*
• Pending: ${pendingWithdrawals}
• Completed: ${completedWithdrawals}
• Total Paid: ${formatCurrency(totalPaid.length > 0 ? totalPaid[0].total : 0)}

📋 *Tasks*
• Active: ${activeTasks}
• Expired/Completed: ${expiredTasks}
    `.trim();
    
    await ctx.reply(statsMessage, { parse_mode: 'Markdown' });
  } catch (error) {
    console.error('Statistics error:', error);
    await ctx.reply('❌ Error loading statistics.');
  }
};

// Settings
const showSettings = async (ctx) => {
  let settings = await Settings.findOne({ key: 'settings' });
  if (!settings) {
    settings = await Settings.create({ key: 'settings', value: config.DEFAULT_SETTINGS });
  }
  
  const settingsMessage = `
⚙ *Current Settings*

💰 Min Withdrawal: ${formatCurrency(settings.value.minimumWithdrawal)}
📢 Force Join: ${settings.value.forceJoinChannel}
💵 Currency: ${settings.value.currency}
👤 Support: ${settings.value.supportUsername}
  `.trim();
  
  await ctx.reply(settingsMessage, {
    parse_mode: 'Markdown',
    ...settingsKeyboard()
  });
};

// Handle admin sessions
const handleAdminSession = async (ctx) => {
  try {
    const userId = ctx.from.id;
    const text = ctx.message.text;
    
    if (text === '❌ Cancel') {
      adminSessions.delete(userId);
      return ctx.reply('✅ Operation cancelled.', mainMenuKeyboard());
    }
    
    const session = adminSessions.get(userId);
    if (!session) return;
    
    if (session.action === 'add_task') {
      await handleAddTaskSession(ctx, session, text);
    } else if (session.action === 'edit_task') {
      await handleEditTaskSession(ctx, session, text);
    } else if (session.action === 'broadcast') {
      await handleBroadcastSession(ctx, session, text);
    } else if (session.action === 'settings') {
      await handleSettingsSession(ctx, session, text);
    }
    
  } catch (error) {
    console.error('Admin session error:', error);
    await ctx.reply('❌ Error processing.');
  }
};

// Add Task Session
const handleAddTaskSession = async (ctx, session, text) => {
  switch (session.step) {
    case 'title':
      session.title = text;
      session.step = 'description';
      await ctx.reply('Enter task description:');
      break;
      
    case 'description':
      session.description = text;
      session.step = 'channel';
      await ctx.reply('Enter channel username (e.g., @channelname):');
      break;
      
    case 'channel':
      session.channelUsername = text;
      session.step = 'reward';
      await ctx.reply('Enter reward amount:');
      break;
      
    case 'reward':
      const reward = parseFloat(text);
      if (isNaN(reward) || reward <= 0) {
        return ctx.reply('❌ Invalid amount. Enter a valid number:');
      }
      session.reward = reward;
      session.step = 'maxUsers';
      await ctx.reply('Enter maximum number of users:');
      break;
      
    case 'maxUsers':
      const maxUsers = parseInt(text);
      if (isNaN(maxUsers) || maxUsers <= 0) {
        return ctx.reply('❌ Invalid number. Enter a valid number:');
      }
      session.maxUsers = maxUsers;
      session.step = 'expiry';
      await ctx.reply('Enter expiry date (DD/MM/YYYY) or type "none":');
      break;
      
    case 'expiry':
      let expiryDate = null;
      if (text.toLowerCase() !== 'none') {
        const parts = text.split('/');
        if (parts.length === 3) {
          expiryDate = new Date(parts[2], parts[1] - 1, parts[0]);
        } else {
          return ctx.reply('❌ Invalid date format. Use DD/MM/YYYY or "none":');
        }
      }
      
      // Create task
      const task = new Task({
        title: session.title,
        description: session.description,
        channelUsername: session.channelUsername,
        reward: session.reward,
        maxUsers: session.maxUsers,
        expiryDate: expiryDate,
        createdBy: ctx.from.id
      });
      await task.save();
      
      adminSessions.delete(ctx.from.id);
      
      await ctx.reply(
        `✅ *Task Created Successfully!*\n\n` +
        `📌 Title: ${task.title}\n` +
        `💰 Reward: ${formatCurrency(task.reward)}\n` +
        `👥 Max Users: ${task.maxUsers}`,
        {
          parse_mode: 'Markdown',
          ...mainMenuKeyboard()
        }
      );
      
      // Broadcast to all users
      const users = await User.find({});
      let sentCount = 0;
      for (const user of users) {
        try {
          await ctx.telegram.sendMessage(
            user.telegramId,
            `🔥 *New Task Available!*\n\n📌 ${task.title}\n💰 Reward: ${formatCurrency(task.reward)}\n\nUse /tasks to view!`,
            { parse_mode: 'Markdown' }
          );
          sentCount++;
        } catch (error) {
          console.error(`Failed to notify user ${user.telegramId}:`, error.message);
        }
      }
      
      await ctx.reply(`📢 Notified ${sentCount}/${users.length} users about new task.`);
      break;
  }
};

// Edit Task Session
const handleEditTaskSession = async (ctx, session, text) => {
  // Implementation for editing tasks
  // Similar structure to add task
};

// Broadcast Session
const handleBroadcastSession = async (ctx, session, text) => {
  if (session.step === 'type') {
    const users = await User.find({});
    let successCount = 0;
    let failCount = 0;
    
    await ctx.reply(`📢 Broadcasting to ${users.length} users...`);
    
    for (const user of users) {
      try {
        await ctx.telegram.sendMessage(user.telegramId, text);
        successCount++;
      } catch (error) {
        failCount++;
      }
    }
    
    adminSessions.delete(ctx.from.id);
    
    await ctx.reply(
      `📢 *Broadcast Complete!*\n\n` +
      `✅ Success: ${successCount}\n` +
      `❌ Failed: ${failCount}\n` +
      `📊 Total: ${users.length}`,
      {
        parse_mode: 'Markdown',
        ...mainMenuKeyboard()
      }
    );
  }
};

// Settings Session
const handleSettingsSession = async (ctx, session, text) => {
  let settings = await Settings.findOne({ key: 'settings' });
  
  switch (session.setting) {
    case 'min_withdrawal':
      const amount = parseFloat(text);
      if (isNaN(amount) || amount < 1) {
        return ctx.reply('❌ Invalid amount. Enter valid number:');
      }
      settings.value.minimumWithdrawal = amount;
      await settings.save();
      adminSessions.delete(ctx.from.id);
      await ctx.reply(`✅ Minimum withdrawal updated to ${formatCurrency(amount)}`, mainMenuKeyboard());
      break;
      
    case 'channel':
      settings.value.forceJoinChannel = text;
      await settings.save();
      adminSessions.delete(ctx.from.id);
      await ctx.reply(`✅ Force join channel updated to ${text}`, mainMenuKeyboard());
      break;
      
    case 'currency':
      settings.value.currency = text;
      await settings.save();
      adminSessions.delete(ctx.from.id);
      await ctx.reply(`✅ Currency updated to ${text}`, mainMenuKeyboard());
      break;
      
    case 'support':
      settings.value.supportUsername = text;
      await settings.save();
      adminSessions.delete(ctx.from.id);
      await ctx.reply(`✅ Support username updated to ${text}`, mainMenuKeyboard());
      break;
  }
};

module.exports = {
  adminHandler,
  adminCallbackHandler,
  handleAdminSession,
  showBroadcastOptions
};