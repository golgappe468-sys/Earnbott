const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  channelUsername: {
    type: String,
    required: true
  },
  channelId: {
    type: String,
    default: ''
  },
  reward: {
    type: Number,
    required: true,
    min: 1
  },
  maxUsers: {
    type: Number,
    required: true,
    min: 1
  },
  completedBy: {
    type: Number,
    default: 0
  },
  expiryDate: {
    type: Date,
    default: null
  },
  status: {
    type: String,
    enum: ['active', 'expired', 'completed'],
    default: 'active'
  },
  image: {
    type: String,
    default: ''
  },
  createdBy: {
    type: Number,
    required: true
  }
}, {
  timestamps: true
});

taskSchema.index({ status: 1 });
taskSchema.index({ expiryDate: 1 });

taskSchema.methods.isExpired = function() {
  if (this.status !== 'active') return true;
  if (this.completedBy >= this.maxUsers) {
    this.status = 'completed';
    return true;
  }
  if (this.expiryDate && new Date() > this.expiryDate) {
    this.status = 'expired';
    return true;
  }
  return false;
};

module.exports = mongoose.model('Task', taskSchema);