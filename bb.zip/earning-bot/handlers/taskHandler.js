const User = require('../models/User');
const Task = require('../models/Task');
const { formatCurrency, getTaskStatus } = require('../utils/helpers');

const tasksHandler = async (ctx) => {
  try {
    const userId = ctx.from.id;
    const user = await User.findOne({ telegramId: userId });
    
    if (!user) {
      return ctx.reply('❌ User not found.');
    }
    
    const activeTasks = await Task.find({ 
      status: 'active',
      $or: [
        { expiryDate: { $gt: new Date() } },
        { expiryDate: null }
      ]
    }).sort({ createdAt: -1 });
    
    if (activeTasks.length === 0) {
      return ctx.reply('📋 No tasks available at the moment.\n\nCheck back later!');
    }
    
    await ctx.reply(`📋 *Available Tasks:* ${activeTasks.length}\n\nSelect a task to view details:`, {
      parse_mode: 'Markdown'
    });
    
    for (const task of activeTasks) {
      const isCompleted = user.completedTasks.some(t => t.taskId.toString() === task._id.toString());
      const taskMessage = `
📌 *${task.title}*
${task.description}

💰 Reward: ${formatCurrency(task.reward)}
👥 Progress: ${task.completedBy}/${task.maxUsers}
📅 Expires: ${task.expiryDate ? new Date(task.expiryDate).toLocaleDateString() : 'No expiry'}
📊 Status: ${getTaskStatus(task)}
      `.trim();
      
      const keyboard = {
        reply_markup: {
          inline_keyboard: [
            [{ text: '📢 Open Channel', url: `https://t.me/${task.channelUsername.replace('@', '')}` }],
            isCompleted 
              ? [{ text: '✅ Completed', callback_data: 'task_done' }]
              : [{ text: '🔍 Verify Completion', callback_data: `verify_task_${task._id}` }]
          ]
        }
      };
      
      if (task.image) {
        await ctx.replyWithPhoto(task.image, {
          caption: taskMessage,
          parse_mode: 'Markdown',
          ...keyboard
        });
      } else {
        await ctx.reply(taskMessage, {
          parse_mode: 'Markdown',
          ...keyboard
        });
      }
    }
    
  } catch (error) {
    console.error('Tasks handler error:', error);
    await ctx.reply('❌ Error loading tasks.');
  }
};

const verifyTaskHandler = async (ctx) => {
  try {
    const userId = ctx.from.id;
    const taskId = ctx.match[1];
    
    const user = await User.findOne({ telegramId: userId });
    if (!user) {
      return ctx.answerCbQuery('❌ User not found.', { show_alert: true });
    }
    
    const task = await Task.findById(taskId);
    if (!task) {
      return ctx.answerCbQuery('❌ Task not found.', { show_alert: true });
    }
    
    // Check if task is still active
    if (task.isExpired()) {
      await task.save();
      return ctx.answerCbQuery('❌ Task has expired.', { show_alert: true });
    }
    
    // Check if already completed
    const alreadyCompleted = user.completedTasks.some(t => t.taskId.toString() === task._id.toString());
    if (alreadyCompleted) {
      return ctx.answerCbQuery('❌ You already completed this task!', { show_alert: true });
    }
    
    // Verify channel membership
    try {
      const chatMember = await ctx.telegram.getChatMember(`@${task.channelUsername.replace('@', '')}`, userId);
      
      if (!['member', 'administrator', 'creator'].includes(chatMember.status)) {
        return ctx.answerCbQuery('❌ Please join the channel first!', { show_alert: true });
      }
      
      // Award reward
      user.balance += task.reward;
      user.totalEarned += task.reward;
      user.completedTasks.push({ taskId: task._id });
      await user.save();
      
      task.completedBy += 1;
      if (task.completedBy >= task.maxUsers) {
        task.status = 'completed';
      }
      await task.save();
      
      await ctx.answerCbQuery(`✅ Task completed! +${task.reward}`, { show_alert: true });
      
      // Update message
      await ctx.editMessageReplyMarkup({
        inline_keyboard: [[{ text: '✅ Completed', callback_data: 'task_done' }]]
      });
      
      // Notify user
      await ctx.reply(
        `✅ *Task Completed!*\n\n📌 ${task.title}\n💰 Reward: ${formatCurrency(task.reward)}\n💵 New Balance: ${formatCurrency(user.balance)}`,
        { parse_mode: 'Markdown' }
      );
      
    } catch (error) {
      console.error('Task verification error:', error);
      await ctx.answerCbQuery('❌ Could not verify membership. Try again.', { show_alert: true });
    }
    
  } catch (error) {
    console.error('Verify task handler error:', error);
    await ctx.answerCbQuery('❌ An error occurred.', { show_alert: true });
  }
};

module.exports = { tasksHandler, verifyTaskHandler };