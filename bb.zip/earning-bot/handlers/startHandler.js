const User = require('../models/User');
const Settings = require('../models/Settings');
const config = require('../config');
const { mainMenuKeyboard } = require('../keyboards/mainMenu');

const startHandler = async (ctx) => {
  try {
    const userId = ctx.from.id;
    const username = ctx.from.username || '';
    const firstName = ctx.from.first_name || '';
    const lastName = ctx.from.last_name || '';
    
    // Check if user exists
    let user = await User.findOne({ telegramId: userId });
    
    if (!user) {
      user = new User({
        telegramId: userId,
        username,
        firstName,
        lastName,
        joinedDate: new Date()
      });
      await user.save();
    } else {
      // Update user info
      user.username = username;
      user.firstName = firstName;
      user.lastName = lastName;
      await user.save();
    }
    
    const welcomeMessage = `
🎉 *Welcome to Earn Bot!*

Earn money by completing simple tasks!

📋 *Available Features:*
• Complete tasks and earn rewards
• Withdraw earnings via UPI
• Track your balance

💡 Use the buttons below to navigate.

Happy earning! 💰
    `.trim();
    
    await ctx.reply(welcomeMessage, {
      parse_mode: 'Markdown',
      ...mainMenuKeyboard()
    });
    
  } catch (error) {
    console.error('Start handler error:', error);
    await ctx.reply('❌ An error occurred. Please try again.');
  }
};

const verifyJoinHandler = async (ctx) => {
  try {
    const userId = ctx.from.id;
    const settings = await Settings.findOne({ key: 'settings' });
    const channelId = settings ? settings.value.forceJoinChannelId : config.FORCE_JOIN_CHANNEL_ID;
    
    const chatMember = await ctx.telegram.getChatMember(channelId, userId);
    
    if (['member', 'administrator', 'creator'].includes(chatMember.status)) {
      await ctx.answerCbQuery('✅ Verified successfully!');
      await ctx.deleteMessage();
      await startHandler(ctx);
    } else {
      await ctx.answerCbQuery('❌ Please join the channel first!', { show_alert: true });
    }
  } catch (error) {
    console.error('Verify join error:', error);
    await ctx.answerCbQuery('❌ Verification failed. Please try again.', { show_alert: true });
  }
};

module.exports = { startHandler, verifyJoinHandler };