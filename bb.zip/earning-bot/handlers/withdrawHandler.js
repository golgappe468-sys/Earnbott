const User = require('../models/User');
const Withdrawal = require('../models/Withdrawal');
const Settings = require('../models/Settings');
const config = require('../config');
const { validateUPI, formatCurrency } = require('../utils/helpers');
const { cancelKeyboard, mainMenuKeyboard } = require('../keyboards/mainMenu');

// Store temporary withdrawal data
const withdrawalSessions = new Map();

const withdrawHandler = async (ctx) => {
  try {
    const userId = ctx.from.id;
    const user = await User.findOne({ telegramId: userId });
    
    if (!user) {
      return ctx.reply('❌ User not found.');
    }
    
    const settings = await Settings.findOne({ key: 'settings' });
    const minWithdrawal = settings ? settings.value.minimumWithdrawal : config.MINIMUM_WITHDRAWAL;
    
    if (user.balance < minWithdrawal) {
      return ctx.reply(
        `❌ *Insufficient Balance*\n\n` +
        `Minimum withdrawal: ${formatCurrency(minWithdrawal)}\n` +
        `Your balance: ${formatCurrency(user.balance)}\n\n` +
        `Complete more tasks to reach the minimum.`,
        { parse_mode: 'Markdown' }
      );
    }
    
    if (user.pendingWithdrawal) {
      return ctx.reply('⏳ You already have a pending withdrawal request.');
    }
    
    // Start withdrawal session
    withdrawalSessions.set(userId, { step: 'amount' });
    
    await ctx.reply(
      `💸 *Withdrawal Request*\n\n` +
      `Enter the amount you want to withdraw:\n` +
      `Minimum: ${formatCurrency(minWithdrawal)}\n` +
      `Maximum: ${formatCurrency(user.balance)}\n\n` +
      `Reply with the amount or click Cancel:`,
      {
        parse_mode: 'Markdown',
        ...cancelKeyboard()
      }
    );
    
  } catch (error) {
    console.error('Withdraw handler error:', error);
    await ctx.reply('❌ Error processing withdrawal.');
  }
};

const handleWithdrawalSession = async (ctx) => {
  try {
    const userId = ctx.from.id;
    const text = ctx.message.text;
    
    if (text === '❌ Cancel') {
      withdrawalSessions.delete(userId);
      return ctx.reply('✅ Withdrawal cancelled.', mainMenuKeyboard());
    }
    
    const session = withdrawalSessions.get(userId);
    if (!session) return;
    
    if (session.step === 'amount') {
      const amount = parseFloat(text);
      const user = await User.findOne({ telegramId: userId });
      
      if (!user) {
        withdrawalSessions.delete(userId);
        return ctx.reply('❌ User not found.');
      }
      
      const settings = await Settings.findOne({ key: 'settings' });
      const minWithdrawal = settings ? settings.value.minimumWithdrawal : config.MINIMUM_WITHDRAWAL;
      
      if (isNaN(amount) || amount < minWithdrawal || amount > user.balance) {
        return ctx.reply(
          `❌ Invalid amount!\n\n` +
          `Enter amount between ${formatCurrency(minWithdrawal)} and ${formatCurrency(user.balance)}`,
          cancelKeyboard()
        );
      }
      
      session.amount = amount;
      session.step = 'upi';
      
      await ctx.reply(
        '📱 *Enter UPI ID*\n\n' +
        'Enter your UPI ID (e.g., username@upi):',
        {
          parse_mode: 'Markdown',
          ...cancelKeyboard()
        }
      );
      
    } else if (session.step === 'upi') {
      if (!validateUPI(text)) {
        return ctx.reply(
          '❌ Invalid UPI ID format!\n\n' +
          'Please enter a valid UPI ID (e.g., username@upi):',
          cancelKeyboard()
        );
      }
      
      const user = await User.findOne({ telegramId: userId });
      
      // Create withdrawal request
      const withdrawal = new Withdrawal({
        userId: user.telegramId,
        username: user.username || user.firstName,
        amount: session.amount,
        upiId: text,
        status: 'pending'
      });
      await withdrawal.save();
      
      user.pendingWithdrawal = true;
      await user.save();
      
      withdrawalSessions.delete(userId);
      
      // Notify user
      await ctx.reply(
        `✅ *Withdrawal Request Submitted!*\n\n` +
        `💰 Amount: ${formatCurrency(session.amount)}\n` +
        `📱 UPI: ${text}\n` +
        `📊 Status: Pending\n\n` +
        `Your request will be processed soon.`,
        {
          parse_mode: 'Markdown',
          ...mainMenuKeyboard()
        }
      );
      
      // Notify admins
      const adminIds = config.ADMIN_IDS;
      for (const adminId of adminIds) {
        try {
          await ctx.telegram.sendMessage(
            adminId,
            `🔔 *New Withdrawal Request*\n\n` +
            `👤 User: @${user.username || user.firstName}\n` +
            `🆔 ID: ${user.telegramId}\n` +
            `💰 Amount: ${formatCurrency(session.amount)}\n` +
            `📱 UPI: ${text}\n\n` +
            `Use /admin to process`,
            {
              parse_mode: 'Markdown',
              reply_markup: {
                inline_keyboard: [[
                  { text: '✅ Approve', callback_data: `approve_wd_${withdrawal._id}` },
                  { text: '❌ Reject', callback_data: `reject_wd_${withdrawal._id}` }
                ]]
              }
            }
          );
        } catch (error) {
          console.error('Failed to notify admin:', adminId, error);
        }
      }
    }
    
  } catch (error) {
    console.error('Withdrawal session error:', error);
    await ctx.reply('❌ Error processing request.');
    withdrawalSessions.delete(ctx.from.id);
  }
};

const processWithdrawal = async (ctx) => {
  try {
    const adminId = ctx.from.id;
    const callbackData = ctx.callbackQuery.data;
    
    if (!config.ADMIN_IDS.includes(adminId)) {
      return ctx.answerCbQuery('⛔ Admin only!', { show_alert: true });
    }
    
    const [action, , withdrawalId] = callbackData.split('_');
    
    const withdrawal = await Withdrawal.findById(withdrawalId);
    if (!withdrawal) {
      return ctx.answerCbQuery('❌ Request not found.', { show_alert: true });
    }
    
    if (withdrawal.status !== 'pending') {
      return ctx.answerCbQuery(`❌ Request already ${withdrawal.status}.`, { show_alert: true });
    }
    
    const user = await User.findOne({ telegramId: withdrawal.userId });
    if (!user) {
      return ctx.answerCbQuery('❌ User not found.', { show_alert: true });
    }
    
    if (action === 'approve') {
      // Approve withdrawal
      user.balance -= withdrawal.amount;
      user.totalWithdrawn += withdrawal.amount;
      user.pendingWithdrawal = false;
      await user.save();
      
      withdrawal.status = 'approved';
      withdrawal.processedBy = adminId;
      withdrawal.processedAt = new Date();
      await withdrawal.save();
      
      await ctx.editMessageReplyMarkup({
        inline_keyboard: [[{ text: `✅ Approved by ${ctx.from.first_name}`, callback_data: 'done' }]]
      });
      
      await ctx.answerCbQuery('✅ Withdrawal approved!', { show_alert: true });
      
      // Notify user
      try {
        await ctx.telegram.sendMessage(
          withdrawal.userId,
          `✅ *Withdrawal Approved!*\n\n` +
          `💰 Amount: ${formatCurrency(withdrawal.amount)}\n` +
          `📱 UPI: ${withdrawal.upiId}\n\n` +
          `Your withdrawal has been processed.`,
          { parse_mode: 'Markdown' }
        );
      } catch (error) {
        console.error('Failed to notify user:', error);
      }
      
    } else if (action === 'reject') {
      // Reject withdrawal
      user.pendingWithdrawal = false;
      await user.save();
      
      withdrawal.status = 'rejected';
      withdrawal.processedBy = adminId;
      withdrawal.processedAt = new Date();
      await withdrawal.save();
      
      await ctx.editMessageReplyMarkup({
        inline_keyboard: [[{ text: `❌ Rejected by ${ctx.from.first_name}`, callback_data: 'done' }]]
      });
      
      await ctx.answerCbQuery('❌ Withdrawal rejected!', { show_alert: true });
      
      // Notify user
      try {
        await ctx.telegram.sendMessage(
          withdrawal.userId,
          `❌ *Withdrawal Rejected*\n\n` +
          `💰 Amount: ${formatCurrency(withdrawal.amount)}\n\n` +
          `Your withdrawal request was rejected. Please contact support.`,
          { parse_mode: 'Markdown' }
        );
      } catch (error) {
        console.error('Failed to notify user:', error);
      }
    }
    
  } catch (error) {
    console.error('Process withdrawal error:', error);
    await ctx.answerCbQuery('❌ Error processing request.', { show_alert: true });
  }
};

module.exports = { withdrawHandler, handleWithdrawalSession, processWithdrawal };