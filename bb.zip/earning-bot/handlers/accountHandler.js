const User = require('../models/User');
const { formatCurrency, formatDate } = require('../utils/helpers');

const accountHandler = async (ctx) => {
  try {
    const userId = ctx.from.id;
    const user = await User.findOne({ telegramId: userId });
    
    if (!user) {
      return ctx.reply('❌ User not found. Please start the bot again.');
    }
    
    const accountMessage = `
👤 *Account Information*

🆔 Telegram ID: \`${user.telegramId}\`
👤 Username: ${user.username ? '@' + user.username : 'Not set'}
👨 Name: ${user.firstName} ${user.lastName}

💰 *Balance Information*
💵 Current Balance: ${formatCurrency(user.balance)}
📈 Total Earned: ${formatCurrency(user.totalEarned)}
💸 Total Withdrawn: ${formatCurrency(user.totalWithdrawn)}

📅 Joined: ${formatDate(user.joinedDate)}
📝 Tasks Completed: ${user.completedTasks.length}
    `.trim();
    
    await ctx.reply(accountMessage, { parse_mode: 'Markdown' });
  } catch (error) {
    console.error('Account handler error:', error);
    await ctx.reply('❌ Error fetching account info.');
  }
};

module.exports = { accountHandler };