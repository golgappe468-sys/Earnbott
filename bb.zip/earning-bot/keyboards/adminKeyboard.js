const adminKeyboard = () => {
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text: '➕ Add Task', callback_data: 'admin_add_task' }],
        [{ text: '✏️ Edit Task', callback_data: 'admin_edit_task' }],
        [{ text: '🗑 Delete Task', callback_data: 'admin_delete_task' }],
        [{ text: '💸 Withdraw Requests', callback_data: 'admin_withdrawals' }],
        [{ text: '📢 Broadcast', callback_data: 'admin_broadcast' }],
        [{ text: '📊 Statistics', callback_data: 'admin_stats' }],
        [{ text: '⚙ Settings', callback_data: 'admin_settings' }],
        [{ text: '❌ Close', callback_data: 'admin_close' }]
      ]
    }
  };
};

const broadcastTypeKeyboard = () => {
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text: '📝 Text', callback_data: 'broadcast_text' }],
        [{ text: '🖼 Photo', callback_data: 'broadcast_photo' }],
        [{ text: '🎥 Video', callback_data: 'broadcast_video' }],
        [{ text: '📄 Document', callback_data: 'broadcast_document' }],
        [{ text: '❌ Cancel', callback_data: 'admin_back' }]
      ]
    }
  };
};

const withdrawalActionKeyboard = (withdrawalId) => {
  return {
    reply_markup: {
      inline_keyboard: [
        [
          { text: '✅ Approve', callback_data: `approve_wd_${withdrawalId}` },
          { text: '❌ Reject', callback_data: `reject_wd_${withdrawalId}` }
        ]
      ]
    }
  };
};

const settingsKeyboard = () => {
  return {
    reply_markup: {
      inline_keyboard: [
        [{ text: '💰 Min Withdrawal', callback_data: 'settings_min_wd' }],
        [{ text: '📢 Force Join Channel', callback_data: 'settings_channel' }],
        [{ text: '💵 Currency', callback_data: 'settings_currency' }],
        [{ text: '👤 Support Username', callback_data: 'settings_support' }],
        [{ text: '🔙 Back', callback_data: 'admin_back' }]
      ]
    }
  };
};

module.exports = {
  adminKeyboard,
  broadcastTypeKeyboard,
  withdrawalActionKeyboard,
  settingsKeyboard
};