const mainMenuKeyboard = () => {
  return {
    reply_markup: {
      keyboard: [
        [{ text: '👤 Account' }, { text: '📋 Tasks' }],
        [{ text: '💸 Withdraw' }, { text: '📊 Statistics' }],
        [{ text: '🆘 Help' }, { text: '📢 Channel' }]
      ],
      resize_keyboard: true,
      persistent: true
    }
  };
};

const backToMenuKeyboard = () => {
  return {
    reply_markup: {
      keyboard: [[{ text: '🔙 Back to Menu' }]],
      resize_keyboard: true
    }
  };
};

const cancelKeyboard = () => {
  return {
    reply_markup: {
      keyboard: [[{ text: '❌ Cancel' }]],
      resize_keyboard: true
    }
  };
};

module.exports = { mainMenuKeyboard, backToMenuKeyboard, cancelKeyboard };