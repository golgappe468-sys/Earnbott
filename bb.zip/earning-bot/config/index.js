require('dotenv').config();

module.exports = {
  BOT_TOKEN: process.env.BOT_TOKEN,
  MONGODB_URI: process.env.MONGODB_URI,
  ADMIN_IDS: (process.env.ADMIN_IDS || '').split(',').map(id => parseInt(id.trim())),
  FORCE_JOIN_CHANNEL: process.env.FORCE_JOIN_CHANNEL || '@earninbotchannel',
  FORCE_JOIN_CHANNEL_ID: process.env.FORCE_JOIN_CHANNEL_ID || '-1001234567890',
  MINIMUM_WITHDRAWAL: 100,
  CURRENCY: '₹',
  DEFAULT_SETTINGS: {
    minimumWithdrawal: 100,
    forceJoinChannel: '@earninbotchannel',
    forceJoinChannelId: '-1001234567890',
    currency: '₹',
    supportUsername: '@admin'
  }
};